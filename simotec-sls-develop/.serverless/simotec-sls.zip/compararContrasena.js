const bcrypt = require("bcryptjs");

const storedHash = "$2a$10$Kh6DA4oUzivX.cpYDrEqiee7pqIovRK6VQI17XHVfAkO5JY61NFDG"; // Copia el hash real de la BD
const inputPassword = "AdminPucv456!"; // La contraseña original

bcrypt.compare(inputPassword, storedHash)
  .then(result => console.log("¿Coincide la contraseña?", result))
  .catch(err => console.error("Error comparando:", err));
